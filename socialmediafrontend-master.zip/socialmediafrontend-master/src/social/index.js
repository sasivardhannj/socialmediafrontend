import React from 'react';
import SocialFollow from './SocialFollow';
import './style.css';

export default function index(){
    return (
        <div className='App'>
          <SocialFollow />
        </div>
    )
}